// RMIT University Vietnam
//  Course: COSC2430 Web Programming
//  Semester: 2023A
//  Assessment: Assignment 2
//  Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
//  ID: s3940575, s3914532, s3866724, s3926629, s3977947 
 
function previewImage(event) {
  const reader = new FileReader();
  reader.onload = function() {
    const imagePreview = document.getElementById("imagePreview");
    imagePreview.innerHTML = '<img src="' + reader.result + '" />';
  }
  reader.readAsDataURL(event.target.files[0]);
}

function validateForm() {
  // Get the values of the input fields
  const productName = document.getElementById("productname").value;
  const productPrice = document.getElementById("productprice").value;
  const productDescription = document.getElementById("productdescription").value;

  // Check if the product name is between 10 and 20 characters long
  if (productName.length < 10 || productName.length > 20) {
    alert("Product name must be between 10 and 20 characters long.");
    return false;
  }

  // Check if the product price is a positive number
  if (productPrice <= 0) {
    alert("Product price must be a positive number.");
    return false;
  }

  // Check if the product description is at most 500 characters long
  if (productDescription.length > 500) {
    alert("Product description must be at most 500 characters long.");
    return false;
  }

  // If all the validations pass, return true to submit the form
  return true;
}
  function validateForm() {
    const productName = document.getElementById("productname").value.trim();
    const productPrice = document.getElementById("productprice").value.trim();
    const productDescription = document.getElementById("productdescription").value.trim();
  
    // Validate product name
    if (productName.length < 10 || productName.length > 20) {
      alert("Product name must have a length between 10 and 20 characters.");
      return false;
    }
  
    // Validate product price
    if (isNaN(productPrice) || productPrice <= 0) {
      alert("Product price must be a positive number.");
      return false;
    }
  
    // Validate product description
    if (productDescription.length > 500) {
      alert("Product description must be at most 500 characters.");
      return false;
    }
    // Form is valid
    return true;
  }
