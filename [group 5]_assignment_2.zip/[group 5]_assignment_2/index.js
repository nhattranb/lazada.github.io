//  RMIT University Vietnam
//  Course: COSC2430 Web Programming
//  Semester: 2023A
//  Assessment: Assignment 2
//  Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
//  ID: s3940575, s3914532, s3866724, s3926629, s3977947

const express = require('express');
const bodyParser = require('body-parser');
const app = express();
var path = require('path');
const User = require('./src/userschema');
const Product = require('./src/productschema');
const multer = require('multer');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');

const { MongoDBRepository } = require('./src/mongo.repository');
const database = new MongoDBRepository('mongodb+srv://donhatthanh1:thanh1357@cluster0.zkeaoqw.mongodb.net/laz');

const indexRouter = require('./src/route');
const userController = require('./src/userdata');

// Set the view engine to EJS
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// Serve static files from the views/pages directory
app.use(express.static(__dirname + '/views/pages'));

// Use middlewares
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

// Connect to the MongoDB database
database.connectDB();

// Register the route handlers
app.use('/', indexRouter);
app.post('/signup', userController.signup);

// Start the server
app.listen(8080, () => {
  console.log('Server is listening on port 8080');
});


//multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'views/pages/uploads/') // specify the destination folder for uploaded files
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname) // use the original file name as the new file name
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 5 // 5 MB file size limit
  },
  fileFilter: function(req, file, cb) {
    if (file.mimetype !== 'image/png') {
      cb(new Error('Only PNG images are allowed'));
    } else {
      cb(null, true);
    }
  }
});

//add products
app.post('/products', upload.single('productimage'), async function(req, res) {
  console.log(req.file);
  const newProduct = new Product({
    productname: req.body.productname,
    productimage: req.file.path, // use the path to the uploaded file
    productprice: req.body.productprice,
    productdescription: req.body.productdescription
  });
  try {
    const savedProduct = await newProduct.save();
    res.send("<script>alert('User created successfully'); window.location.href = '/vendor';</script>");
  } catch (err) {
    console.error(err);
    res.send('<script>alert("Error creating product!"); window.location.href="/products";</script>');
  }
});

//login
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  // Find user in database
  const user = await User.findOne({ username });

  // Check if user exists
  if (!user) {
    return res.send(`
      <script>
        alert('Invalid username or password');
        window.location.href = '/login';
      </script>
    `);
  }
  // Check if password is correct
  const passwordMatch = await bcrypt.compare(password, user.password);
  if (!passwordMatch) {
    return res.send(`
      <script>
        alert('Invalid username or password');
        window.location.href = '/login';
      </script>
    `);
  }
  // Redirect user based on userRole
  if (user.userRole === 'user') {
    res.redirect('/');
  } else if (user.userRole === 'shipper') {
    res.redirect('/hub');
  } else if (user.userRole === 'vendor') {
    res.redirect('/products');
  }
});
