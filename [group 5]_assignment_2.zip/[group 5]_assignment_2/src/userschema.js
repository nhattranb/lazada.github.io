// RMIT University Vietnam
// Course: COSC2430 Web Programming
// Semester: 2023A
// Assessment: Assignment 2
// Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
// ID: s3940575, s3914532, s3866724, s3926629, s3977947


const mongoose = require('mongoose');

// Define the schema for the User collection
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    unique: false,
  },
  username: {
    type: String,
    unique: true,
  },
  password:{
    type: String,
    unique: false,
  },
  userRole: {
    type: String,
    enum: ['shipper', 'user', 'vendor'],
  },
  hub: {
    type: String,
    enum: ['Hanoi', 'HCM', 'Singapore',''],
  }
});

// Create a User model based on the schema
const User = mongoose.model('User', userSchema);

module.exports = User;