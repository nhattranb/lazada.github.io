// RMIT University Vietnam
// Course: COSC2430 Web Programming
// Semester: 2023A
// Assessment: Assignment 2
// Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
// ID: s3940575, s3914532, s3866724, s3926629, s3977947
// routes/index.js

const express = require('express');
const router = express.Router();
const { orderSchema, Order } = require('./orderschema.js');
const User = require('./userschema.js');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const Product = require('./productschema.js');

router.use(cookieParser());
// Handle GET request for the root path

router.get('/', (req, res) => {
  res.render('pages');
});

router.get('/signup', (req, res) => {
  res.render('pages/signup');
});

router.get('/hub', (req, res) => {
  Order.find({})
    .then(orders => {
      res.render('pages/hub', { orders });
    })
    .catch(err => {
      console.log(err);
    });
});
router.get('/uploads', (req, res) => {
  res.render('/uploads');
});
router.get('/products', (req, res) => {
  res.render('pages/products');
});

router.get('/login', (req, res) => {
  res.render('pages/login');
});

router.get('/myaccount', async (req, res) => {
  try {

    // Fetch the user from the database
    const user = await User.findOne({ username: "donhatthanh1" }).exec();

    if (!user) {
      // User not found, redirect to login page or display an error message
      return res.redirect('/login');
    }

    // Render the EJS template with the user information
    res.render('pages/myaccount', { userInfo: user });
  } catch (err) {
    console.error(err);
    res.status(500).send('Internal Server Error');
  }
});
router.get('/vendor', (req, res) => {
  Product.find({})
  .then(products => {
    res.render('pages/vendor', { products });
  })
  .catch(err => {
    console.log(err);
  });
});

router.get('/cart', (req, res) => {
  res.render('pages/cart');
});
module.exports = router;