// RMIT University Vietnam
// Course: COSC2430 Web Programming
// Semester: 2023A
// Assessment: Assignment 2
// Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
// ID: s3940575, s3914532, s3866724, s3926629, s3977947

const mongoose = require('mongoose');

// Define the schema for the User collection
const orderSchema = new mongoose.Schema({
  name: {type: String,},
  date: {type: String,},
  hub:{type: String,},
  total_price: {type: String,},
  address: {type: String,}
});

// Create a User model based on the schema

const Order = mongoose.model('Order', orderSchema);

module.exports = { orderSchema, Order };