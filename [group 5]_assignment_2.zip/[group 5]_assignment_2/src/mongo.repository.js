// RMIT University Vietnam
// Course: COSC2430 Web Programming
// Semester: 2023A
// Assessment: Assignment 2
// Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
// ID: s3940575, s3914532, s3866724, s3926629, s3977947

const mongoose = require('mongoose');

// Define the MongoDB repository class
class MongoDBRepository {
  constructor(connectionString) {
    this.connectionString = connectionString;
  }

  connectDB() {
    // Connect to the MongoDB database using the provided connection string
    mongoose.connect(this.connectionString, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    // Get a reference to the default connection
    const db = mongoose.connection;

    // Handle database connection errors
    db.on('error', (err) => {
      console.error('Error connecting to MongoDB:', err);
    });

    // Log a success message when the database connection is established
    db.once('open', () => {
      console.log('Connected to MongoDB');
    });
  }
}

module.exports = { MongoDBRepository };