RMIT University Vietnam
Course: COSC2430 Web Programming
Semester: 2023A
Assessment: Assignment 2
Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
ID: s3940575, s3914532, s3866724, s3926629, s3977947

Link to Github repository: https://github.com/nhattranb/lazada.github.io
Link to the video: will be updated later.
Testing Accounts: 
username: Customer
password: Customer123!

username: Vendor
password: Vendor123!

username: Shipper
password: Shipper123!

setup : 
npm install ( install all the modules required )
npm start (start the nodejs application)
localhost:8080 will be the link to our application