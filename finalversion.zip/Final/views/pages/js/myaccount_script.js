// RMIT University Vietnam
//  Course: COSC2430 Web Programming
//  Semester: 2023A
//  Assessment: Assignment 2
//  Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
//  ID: s3940575, s3914532, s3866724, s3926629, s3977947 
 
document.getElementById('button-upload').addEventListener('click', function() {
  var fileInput = document.getElementById('upload-image');
  var profileImage = document.getElementById('image');

  var file = fileInput.files[0];
  var reader = new FileReader();

  reader.onload = function(e) {
    profileImage.src = e.target.result;
  };

  reader.readAsDataURL(file);
});


document.getElementById('log-out').addEventListener('click', function() {

  alert('Logged out successfully');
});

