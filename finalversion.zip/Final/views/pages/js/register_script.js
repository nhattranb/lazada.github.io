// RMIT University Vietnam
//  Course: COSC2430 Web Programming
//  Semester: 2023A
//  Assessment: Assignment 2
//  Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
//  ID: s3940575, s3914532, s3866724, s3926629, s3977947 
 
function ResetForm() {
  document.getElementById("register").reset();
}

// Hides the hub selection field if the "shipper" radio button is not selected
function hideHub() {
  const hubSelection = document.getElementById("hub");
  const shipperRadio = document.getElementById("user-shipper");
  const hubLabel = document.querySelector('label[for="hub"]');

  if (shipperRadio.checked) {
    hubSelection.style.display = "block";
    hubLabel.style.display = "block";
    hubSelection.required = true;
  } else {
    hubSelection.style.display = "none";
    hubLabel.style.display = "none";
    hubSelection.required = false;
  }
}

// Validates the username field
function validateUsername(username) {
  if (!username) {
    alert('Please enter a username.');
    return false;
  }
  if (username.length < 5) {
    alert('Username must be at least 5 characters long.');
    return false;
  }
  return true;
}

// Validates the password field
function validatePassword(password) {
  if (!password) {
    alert('Please enter a password.');
    return false;
  }
  if (password.length < 8) {
    alert('Password must be at least 8 characters long.');
    return false;
  }
  if (!/[A-Z]/.test(password)) {
    alert('Password must contain at least one uppercase letter.');
    return false;
  }
  if (!/\d/.test(password)) {
    alert('Password must contain at least one digit.');
    return false;
  }
  if (!/[!@#$%^&+=]/.test(password)) {
    alert('Password must contain at least one special character (!@#$%^&+=).');
    return false;
  }
  return true;
}

// Validates the confirm password field
function validateConfirmPassword() {
  var password = document.getElementById("password").value;
  var confirmPassword = document.getElementById("confirm-password").value;

  if (password != confirmPassword) {
    alert("Passwords do not match");
    return false;
  }
  return true;
}

// Validates the name field
function validateName(name) {
  if (name.length < 5) {
    alert("Name must be at least 5 characters long");
    return false;
  }
  return true;
}

// Validates the entire form
function validateForm() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirm-password').value;
  const name = document.getElementById('name').value;
  const userRoleShipper = document.getElementById('user-shipper').checked;
  const hub = document.getElementById('hub').value;
  
  if (!validateName(name)) {
    return false;
  }
  if (!validateConfirmPassword(confirmPassword)) {
    return false;
  }
  if (!validateUsername(username)) {
    return false;
  }
  if (!validatePassword(password)) {
    return false;
  }
  if (userRoleShipper && !hub) {
    alert('Please select a hub for shippers.');
    return false;
  }
  return true;
}

// Adds an event listener to the form's submit event
function onSubmit(event) {
  event.preventDefault(); // prevent the default form submission behavior

  if (validateForm()) {
    const form = document.getElementById('register');
    form.submit(); // execute the form action if the form is valid
  }
}


