// RMIT University Vietnam
// Course: COSC2430 Web Programming
// Semester: 2023A
// Assessment: Assignment 2
// Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
// ID: s3940575, s3914532, s3866724, s3926629, s3977947

const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('./userschema');

// Handle POST request to create a new user
exports.signup = async (req, res) => {
  const { name, username, password, hub, userRole } = req.body;
  console.log("🚀 ~ file: userdata.js:8 ~ exports.signup= ~ req.body:", req.body)

  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user document with the hashed password
    const user = new User({
      name,
      username,
      password: hashedPassword,
      hub: hub,
      userRole: userRole,
    });

    // Save the user document to the database
    await user.save();
    console.log('User created successfully');
    res.send("<script>alert('User created successfully'); window.location.href = '/signup';</script>");
  } catch (err) {
    console.error(err);
    res.send("<script>alert('Error creating user, try changing your username'); window.location.href = '/signup';</script>");
  }
};