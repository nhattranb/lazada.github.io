// RMIT University Vietnam
// Course: COSC2430 Web Programming
// Semester: 2023A
// Assessment: Assignment 2
// Authors: Cho Jimin, Cho Jaesuk, Kim Minsung, Tran Minh Nhat, Do Nhat Thanh
// ID: s3940575, s3914532, s3866724, s3926629, s3977947

const mongoose = require('mongoose');
const productSchema = new mongoose.Schema({
    productname: String,
    productimage: String,
    productprice: Number,
    productdescription: String
  });

  const Product = mongoose.model('Product', productSchema);
  module.exports = Product;